# WPA Translator Root System v3

Овој пакет е коренска стабилизација на WPA преведувачот и македонскиот правописен слој.

## Што решава

- Македонскиот (`mk`) е master/canonical language.
- Англискиот (`en`) е mirror layer.
- 50 јазици се подготвени како controlled rollout.
- Нема frontend API клучеви.
- Нема автоматски машински превод што може да го расипе академскиот текст.
- Страницата не смее да стане blank ако недостасува locale или key.
- Македонски proofreader ги фаќа најчестите WPA грешки и mixed-script slips.
- Translator CI проверува manifest, locale JSON и задолжителни фајлови.

## Фајлови за внесување во repo root

```txt
translator-loader-v2.js
wpa-mk-proofreader.js
translator-root-governance-v3.json
WPA_TRANSLATOR_ROOT_SNIPPET_v3.html
locales/
scripts/translator_quality_check.py
.github/workflows/translator-quality.yml
```

## Јазици

Пакетот содржи 50 јазици:

```txt
mk, en, sq, el, sr, hr, bs, sl, bg, ro, de, fr, it, es, pt, nl, pl, cs, sk, hu, sv, da, no, fi, et, lv, lt, uk, ru, tr, ar, he, hi, ur, fa, zh-Hans, zh-Hant, ja, ko, id, ms, sw, am, ha, af, vi, th, bn, ta, tl
```

## Како да го врзеш на страница

На секоја root страница треба да има:

```html
<body data-page="index">
```

и пред `</body>`:

```html
<script>
  window.WPATranslatorConfig = {
    defaultLanguage: "mk",
    canonicalLanguage: "mk",
    fallbackLanguage: "mk",
    mirrorLanguage: "en",
    manifestPath: "./locales/manifest.json",
    localeBasePath: "./locales",
    commonNamespace: "common",
    selectorIds: ["pageLang", "botLang", "uiLang", "aiLang"],
    storageKeys: ["wpa_language", "wpa-lang"],
    enableMacedonianProofreader: true,
    debug: false
  };
</script>
<script src="wpa-mk-proofreader.js" defer></script>
<script src="translator-loader-v2.js" defer></script>
```

## Како се означуваат преводливи елементи

```html
<a data-i18n="nav.programmes" href="programmes.html">Програми</a>
<h1 data-i18n="global.site_name">World Protocol Academy</h1>
<input data-i18n-placeholder="forms.email" placeholder="Вашиот email">
<title data-i18n-title-tag="meta.title">World Protocol Academy</title>
```

## Важно

Ова е core engine. За целосен превод на секоја страница, следниот чекор е page-by-page key migration:
- `index.html`
- `programmes.html`
- `certification.html`
- `wpa-card.html`
- `passive-revenue.html`
- `papers.html`
- `partnerships/index.html`
- `bibliography/index.html`

Но core системот сега е подготвен за целата WPA.
